<!DOCTYPE html>
<html>
<body>

<?php
ECHO "Hello Boy !<br>";
echo "Hello Girl !<br>";
ECHO "Hello Gay !<br>";
?>

</html>
<body>