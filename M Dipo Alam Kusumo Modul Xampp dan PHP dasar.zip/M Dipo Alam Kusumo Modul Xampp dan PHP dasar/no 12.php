<!DOCTYPE html>
<html>
<body>

<?php
$nim = "0411500400";
$nama = "Chotimatul Musyawaroh";

echo "NIM : " . $nim . "<br>";
echo "NAMA : " . $nama;
?>

</html>
<body>