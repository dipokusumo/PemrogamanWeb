<!DOCTYPE html>
<html>
<body>

<?php
define ("NAMA" , "Achmad Solichin");
define ("NILAI" , 90);

//NAMA = "Muhammad": //akan menyebabkan error
echo "NAMA : " . NAMA . "<br>";
echo "NILAI : " . NILAI;
?>

</html>
<body>