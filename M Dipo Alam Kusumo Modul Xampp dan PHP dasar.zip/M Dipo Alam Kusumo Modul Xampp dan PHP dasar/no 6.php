<!DOCTYPE html>
<html>
<body>

<?php
$txt = "Kelas Pemrogaman Web";
$x = 5;
$y = 10.5;

echo $txt;
echo "<br>";
echo $x;
echo "<br>";
echo $y;
?>

</html>
<body>