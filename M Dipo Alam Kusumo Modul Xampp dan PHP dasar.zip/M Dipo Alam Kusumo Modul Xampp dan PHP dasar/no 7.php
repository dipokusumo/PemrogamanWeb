<!DOCTYPE html>
<html>
<body>

<?php
$txt = "Three Girls";
echo "I Love $txt!";
?>

</html>
<body>