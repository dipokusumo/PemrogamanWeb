<!DOCTYPE html>
<html>
<body>

<?php
$nim = "0411500400";
$nama = "Chotimatul Musyawaroh";
$umur = 23;
$nilai = 82.25;
$status = "True";

echo "NIM : " . $nim . "<br>";
echo "NAMA : " . $nama . "<br>";
print "UMUR : " . $umur . "<br>";
print ("NILAI : " . $nilai . "<br>");
if ($status)
echo "STATUS : Aktif";
else 
echo "STATUS : Tidak Aktif";
?>

</html>
<body>