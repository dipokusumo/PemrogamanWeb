<!DOCTYPE html>
<html>
<body>

<?php
echo "<h2>PHP is fun!</h2>";
echo "Hello World!<br>";
echo "I'm about to learn PHP<br>";
echo "This " , "string " , "is " , "made " , "with multiple paramaters.";
?>

</html>
<body>