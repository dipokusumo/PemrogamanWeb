<!DOCTYPE html>
<html>
<body>

<?php
print "<h2>PHP is fun!</h2>";
print "Hayooo Gabung Kelas PHP<br>";
print "Bukan Pemberi Harapan Palsu yaa!";
?>

</html>
<body>