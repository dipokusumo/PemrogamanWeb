<!DOCTYPE html>
<html>
<head>
	<title>Formulir Pendaftaran Siswa Baru | SMK Coding</title>
</head>

<body>
	<header>
		<h3>Formulir Pendaftaran Siswa Baru</h3>
	</header>

	<form action="proses-pendaftaran.php" method="POST">

		<fieldset>

			<p>
				<label for="nama" class="font-bold">Nama:</label>
				<input type="text" name="nama" placeholder="Nama lengkap" />
			</p>
			<p>
				<label for="alamat" class="font-bold">Alamat:</label>
				<textarea name="alamat"></textarea>
			</p>
			<p>
				<label for="jenis_kelamin" class="font-bold">Jenis Kelamin:</label>
				<label>
					<input type="radio" name="jenis_kelamin" value="laki-laki"> Laki-laki
				</label>
				<label>
					<input type="radio" name="jenis_kelamin" value="perempuan"> Perempuan
				</label>
			</p>
			<p>
				<label for="agama" class="font-bold">Agama:</label>
				<select name="agama">
					<option>Islam</option>
					<option>Kristen</option>
					<option>Hindu</option>
					<option>Budha</option>
					<option>Atheis</option>
				</select>
			</p>
			<p>
				<label for="sekolah_asal" class="font-bold">Sekolah Asal:</label>
				<input type="text" name="sekolah_asal" placeholder="Nama sekolah" />
			</p>

			<p>
  				<input type="submit" value="Daftar" name="daftar" />
			</p>

			<p>
				<a href="index.php">Kembali</a>
			</p>

		</fieldset>
	</form>
	
</body>
</html>
