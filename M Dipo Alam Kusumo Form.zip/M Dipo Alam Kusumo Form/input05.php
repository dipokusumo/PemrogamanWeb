<html>
    <head>
        <title>Login Here</title>
    </head>
    <body>
        <form action="proses05.php" method="POST" name="input">
            <h2>Login Here...</h2>
            Username : <input type="text" name="username"><br>
            Password : <input type="password" name="password"><br>
            <input type="submit" name="Login" value="Login">
            <input type="reset" name="reset" value="reset">
        </form>
    </body>
</html>