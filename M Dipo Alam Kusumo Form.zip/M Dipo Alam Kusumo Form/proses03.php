<?php
if (isset($_GET['Input']))
{
    $nama = $_GET['nama'];
    echo "Nama Anda : <b>".$nama."</b>";
}
?>