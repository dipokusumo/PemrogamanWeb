-- Database: 'dbminggul3'

-- Struktur dari tabel 'bljr_login'

CREATE TABLE 'bljr_login' (
'id' int(l1) NOT NULL,
'username' varchar (255) NOT NULL,
'password' varchar (255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latinl;

-- Dumping data for table 'bljr_login'

INSERT INTO 'bljr_login®' ('id', 'username', 'password') VALUES
(1, 'Andi', 'uhuy123'),
(2, 'santoso', 'querty'),
(3, 'samsul', 'dodolpret'),
(4, 'Administrator', 'admind56');