<?php
session_start();
include_once("config.php");

// Memeriksa apakah form login telah disubmit
if (isset($_POST['submit'])) {
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Melakukan query untuk memeriksa data pengguna
    $query = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
    $result = mysqli_query($db, $query);
    $res = mysqli_num_rows($result);

    // Memeriksa apakah pengguna ditemukan
    if ($res > 0) {
        // Data pengguna ditemukan, simpan username dalam session
        $_SESSION["username"] = $username;
        $_SESSION['submit'] = true;

        // Redirect ke halaman beranda atau halaman lainnya
        header("Location: index.php");
        exit(); // tambahkan exit() untuk menghentikan eksekusi kode selanjutnya
    } else {
        // Data pengguna tidak ditemukan, tampilkan pesan kesalahan
        echo "<script>
            alert('Login gagal! username atau password yang anda masukkan salah!');
            </script>";
    }
}

mysqli_close($db);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login Page</title>
  <style>
    body {
      background: url("img/bg.jpg") no-repeat center center fixed;
      background-size: cover;
    }
  </style>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.16/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="flex items-center justify-center h-screen bg-gray-100">
  <div class="bg-white shadow-md rounded px-8 py-6 w-1/3">
    <h2 class="text-2xl mb-4">Login</h2>
    <form method="post">
      <div class="mb-4">
        <label class="block text-gray-700 text-sm font-bold mb-2" for="username">
          Username
        </label>
        <input class="appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" id="username" name="username" type="text" placeholder="Enter your username">
      </div>
      <div class="mb-6">
        <label class="block text-gray-700 text-sm font-bold mb-2" for="password">
          Password
        </label>
        <input class="appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" id="password" name="password" type="password" placeholder="Enter your password">
      </div>
      <div class="flex items-center justify-between">
        <button class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline" type="submit" name="submit">
          Sign In
        </button>
      </div>
    </form>
  </div>
</body>
</html>
