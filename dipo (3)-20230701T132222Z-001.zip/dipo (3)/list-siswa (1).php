<?php include("config.php"); ?>
<!DOCTYPE html>
<html>
<head>
	<title>Pendaftaran Peserta Baru</title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
</head>

<body>
	<header>
		<h3 class="text-center">Pemain yang sudah mendaftar</h3>
	</header>

	<nav class="text-center my-3">
		<a href="form-daftar.php" class="btn btn-primary">[+] Tambah Baru</a>
	</nav>

	<div class="container">
		<table class="table table-bordered">
			<thead>
				<tr>
					<th>Nama</th>
					<th>Alamat</th>
					<th>Jenis Kelamin</th>
					<th>Asal</th>
					<th>Tindakan</th>
				</tr>
			</thead>
			<tbody>
				<?php
				$sql = "SELECT * FROM calon_siswa";
				$query = mysqli_query($db, $sql);

				while($siswa = mysqli_fetch_array($query)){
					echo "<tr>";
					echo "<td>".$siswa['nama']."</td>";
					echo "<td>".$siswa['alamat']."</td>";
					echo "<td>".$siswa['jenis_kelamin']."</td>";
					echo "<td>".$siswa['sekolah_asal']."</td>";

					echo "<td>";
					echo "<a href='form-edit.php?id=".$siswa['id']."' class='btn btn-primary'>Edit</a>";
					echo "<a href='hapus.php?id=".$siswa['id']."' class='btn btn-danger'>Hapus</a>";
					echo "</td>";

					echo "</tr>";
				}
				?>
			</tbody>
		</table>
	
		<p class="text-center">Total: <?php echo mysqli_num_rows($query) ?></p>
	</div>

	<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.min.js"></script>
</body>
</html>
