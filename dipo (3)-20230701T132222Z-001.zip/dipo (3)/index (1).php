<!DOCTYPE html>
<html>
<head>
	<title>Pendaftaran Peserta Baru | Billiard Code</title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
	<style>
		body {
			background-image: url('img/bg.jpg');
			background-repeat: no-repeat;
			background-size: cover;
			background-position: center;
			display: flex;
			justify-content: center;
			align-items: center;
			height: 100vh;
		}
		.container {
			background-color: #fff;
			padding: 20px;
			border-radius: 5px;
		}
	</style>
</head>

<body>
	<div class="container">
		<nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
			<a class="navbar-brand" href="#">Billiard Code</a>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="navbarNav">
				<ul class="navbar-nav ms-auto">
					<li class="nav-item">
						<a class="nav-link" href="form-daftar.php">Daftar Baru</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="list-siswa.php">Pendaftar</a>
					</li>
				</ul>
			</div>
		</nav>

		<!-- Konten Form Daftar atau List Siswa -->
		<!-- Gantikan bagian ini dengan konten yang sesuai -->
		<h2>Selamat datang!</h2>
		<p>Silakan pilih salah satu menu di atas untuk melanjutkan.</p>
	</div>

	<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.min.js"></script>
</body>
</html>
