<!DOCTYPE html>
<html>
<head>
	<title>Formulir Pendaftaran Peserta Baru</title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
	<style>
		.container {
			display: flex;
			justify-content: center;
			align-items: center;
			height: 100vh;
		}

		.form-container {
			max-width: 400px;
			padding: 20px;
			border: 1px solid #ccc;
			border-radius: 5px;
			background-color: #f7f7f7;
		}
	</style>
</head>
<body>
	<div class="container">
		<div class="form-container">
			<form action="proses-pendaftaran.php" method="POST">
				<fieldset>
					<div class="form-group">
						<label for="nama" class="font-bold">Nama:</label>
						<input type="text" name="nama" class="form-control" placeholder="Nama lengkap" />
					</div>
					<div class="form-group">
						<label for="alamat" class="font-bold">Alamat:</label>
						<textarea name="alamat" class="form-control"></textarea>
					</div>
					<div class="form-group">
						<label for="jenis_kelamin" class="font-bold">Jenis Kelamin:</label>
						<label>
							<input type="radio" name="jenis_kelamin" value="laki-laki"> Laki-laki
						</label>
						<label>
							<input type="radio" name="jenis_kelamin" value="perempuan"> Perempuan
						</label>
					</div>
					<div class="form-group">
						<label for="asal" class="font-bold">Asal:</label>
						<input type="text" name="asal" class="form-control" placeholder="Asal kota" />
					</div>
					<div class="form-group">
						<input type="submit" value="Daftar" name="daftar" class="btn btn-primary" />
					</div>
					<div class="form-group">
						<a href="index.php">Kembali</a>
					</div>
				</fieldset>
			</form>
		</div>
	</div>

	<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.min.js"></script>
</body>
</html>
