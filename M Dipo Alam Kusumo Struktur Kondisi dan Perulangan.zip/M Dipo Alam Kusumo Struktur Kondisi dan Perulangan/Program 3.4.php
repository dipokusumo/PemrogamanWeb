<!DOCTYPE html>
<html>
<body>

<?php
$user = "";
if (!isset($user))
{
    echo "Variabel Tidak Ada";
}
else
{
    echo "Variabel Ada";
}
?>

</html>
<body>