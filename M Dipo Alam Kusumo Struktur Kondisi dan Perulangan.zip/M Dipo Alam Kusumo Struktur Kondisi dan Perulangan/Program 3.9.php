<!DOCTYPE html>
<html>
<body>

<?php
$i = 1;
do
{
    echo "$i ";
    $i+=2;
}
while ($i <= 20);
?>

</html>
<body>