<!DOCTYPE html>
<html>
<body>

<?php
$nilai = 80;
if ($nilai >= 60)
{
    echo "Nilai Anda $nilai, Anda Lulus";
}
?>

</html>
<body>